from django.shortcuts import render
from django.http import HttpResponse
from .models import Quiz

# Create your views here.

def index(request):

    quiz1 = Quiz()
    quiz1.textQuestion = 'What is the name of the application used to manage files and folders in Windows?'
    quiz1.numericQuestion = 'How many bits in a byte?'
    quiz1.binaryQuestion = 'Can a computer function without an operating system?'

    return render(request,'testexam/index.html', {'quiz1': quiz1})

def processed(request):

    count = 0
    textAns = "File Manager"
    numericAns = 6
    binaryAns = "No"

    UserAnsText = request.POST["userTextAns"]
    UserAnsNumeric = int(request.POST["userNumericAns"])
    UserAnsBinary = request.POST["userBinaryAns"]

    if textAns == UserAnsText:
        count = count + 1
    if numericAns == UserAnsNumeric:
        count = count + 1
    if binaryAns == UserAnsBinary:
        count = count + 1
    return render(request,'testexam/results.html',{'result':count})
  